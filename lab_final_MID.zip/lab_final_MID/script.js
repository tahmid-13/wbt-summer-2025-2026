const form = document.getElementById("registrationForm");
const message = document.getElementById("message");

let failedAttempts = 0;


const validPassword = "AIUB123";

form.addEventListener("submit", function(event){

    event.preventDefault();

    let firstName = document.getElementById("firstName").value.trim();
    let lastName = document.getElementById("lastName").value.trim();
    let email = document.getElementById("email").value.trim();
    let password = document.getElementById("password").value;
    let category = document.getElementById("category").value;
    let reason = document.getElementById("reason").value.trim();

    let namePattern = /^[A-Za-z]+$/;
    let emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    
    if(!namePattern.test(firstName)){
        alert("First Name is required and must contain alphabets only.");
        return;
    }

   
    if(!namePattern.test(lastName)){
        alert("Last Name is required and must contain alphabets only.");
        return;
    }

    
    if(!emailPattern.test(email)){
        alert("Enter a valid email address.");
        return;
    }

   
    if(password !== validPassword){

        failedAttempts++;

        if(failedAttempts > 3){
            document.getElementById("password").disabled = true;

            alert("Account Locked! More than 3 invalid attempts.");
            return;
        }

        alert("Invalid Password! Attempt: " + failedAttempts);
        return;
    }

    
    let gender = document.querySelector('input[name="gender"]:checked');

    if(!gender){
        alert("Please select a gender.");
        return;
    }

    
    let clubs = document.querySelectorAll('input[name="club"]:checked');

    if(clubs.length === 0){
        alert("Select at least one club.");
        return;
    }

    
    if(category === ""){
        alert("Please choose a club category.");
        return;
    }

   
    if(reason.length < 20){
        alert("Reason must be at least 20 characters.");
        return;
    }

    message.style.color = "green";
    message.innerHTML = "Registration Successful! Welcome to the club.";

    form.reset();
});